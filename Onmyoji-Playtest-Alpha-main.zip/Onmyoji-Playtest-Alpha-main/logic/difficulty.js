export const DIFFICULTIES = {
  easy: {
    label: "Easy",
    partyHP: 70
  },
  normal: {
    label: "Normal",
    partyHP: 50
  },
  hard: {
    label: "Hard",
    partyHP: 30
  }
};
